package com.example.demo.service;

import java.util.ArrayList;

import com.example.demo.bean.ExpenseClaimed;
import com.example.demo.exception.IdException;

public interface ViewExpenseService 
{
	public ExpenseClaimed addExpense(ExpenseClaimed expense);
	public Iterable<ExpenseClaimed> getAllExpense();
	public ExpenseClaimed getExpenseById(int id) throws IdException;

}
