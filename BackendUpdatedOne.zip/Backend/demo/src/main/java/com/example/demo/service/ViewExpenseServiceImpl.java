package com.example.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.ExpenseClaimed;
import com.example.demo.dao.ViewExpenseDao;
import com.example.demo.exception.IdException;

@Service
public class ViewExpenseServiceImpl implements ViewExpenseService
{
	@Autowired
	ViewExpenseDao viewDao;

	@Override
	public ExpenseClaimed addExpense(ExpenseClaimed expense) {
		
		return viewDao.save(expense);
	}

	@Override
	public Iterable<ExpenseClaimed> getAllExpense() {
		
		return viewDao.findAll();
	}

	@Override
	public ExpenseClaimed getExpenseById(int id) throws IdException {
		
		//return viewDao.getExpenseById(id);
		ExpenseClaimed ec = null;
		if(viewDao.existsById(id)) {
			ec =  viewDao.findById(id).get();
			return ec;
		}
		else
			throw new IdException("id does not exist : "+ id);		
	}
	

}
